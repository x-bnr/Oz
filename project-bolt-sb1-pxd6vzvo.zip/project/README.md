# نظام الحضور والانصراف بماسح QR

نظام متكامل لإدارة حضور وانصراف الموظفين باستخدام تقنية QR Code.

## المميزات

- 📱 مسح رموز QR للحضور والانصراف
- 👥 إدارة الموظفين (إضافة، تعديل، حذف)
- 📊 لوحة تقارير متقدمة مع فلترة
- 🕐 كشف التأخير تلقائياً
- 🎴 بطاقات موظفين مع رموز QR فريدة
- 📈 إحصائيات يومية للحضور والغياب

## التقنيات المستخدمة

- React + TypeScript
- Vite
- Tailwind CSS
- Supabase (قاعدة البيانات)
- QR Code Scanner & Generator
- Lucide React (الأيقونات)

## البدء في التطوير

1. استنسخ المشروع
2. نسخ `.env.example` إلى `.env` وأضف بيانات Supabase الخاصة بك
3. تثبيت المكتبات: `npm install`
4. تشغيل المشروع: `npm run dev`

## النشر

### نشر على Netlify

1. ادخل إلى [Netlify](https://app.netlify.com)
2. اسحب مجلد المشروع إلى Netlify Drop
3. أضف متغيرات البيئة:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

### نشر على Vercel

1. ادخل إلى [Vercel](https://vercel.com)
2. استورد المشروع من Git أو ارفع المجلد
3. أضف متغيرات البيئة:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

## قاعدة البيانات

يتضمن المشروع ملف migration جاهز في:
`supabase/migrations/`

## الترخيص

MIT License
