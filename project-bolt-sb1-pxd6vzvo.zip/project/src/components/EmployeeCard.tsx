import { useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { User, Phone, Briefcase, Calendar, Clock } from 'lucide-react';
import type { Employee } from '../lib/supabase';

interface EmployeeCardProps {
  employee: Employee;
}

export function EmployeeCard({ employee }: EmployeeCardProps) {
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (qrCanvasRef.current) {
      QRCode.toCanvas(
        qrCanvasRef.current,
        employee.employee_code,
        {
          width: 150,
          margin: 1,
          color: {
            dark: '#1f2937',
            light: '#ffffff',
          },
        }
      );
    }
  }, [employee.employee_code]);

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden max-w-md mx-auto border-2 border-gray-100">
      <div className="bg-gradient-to-r from-blue-600 to-cyan-600 h-32 relative">
        <div className="absolute -bottom-16 left-1/2 transform -translate-x-1/2">
          <div className="w-32 h-32 rounded-full border-4 border-white shadow-lg overflow-hidden bg-gray-200">
            {employee.photo_url ? (
              <img
                src={employee.photo_url}
                alt={`${employee.first_name} ${employee.last_name}`}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-100 to-cyan-100">
                <User className="w-16 h-16 text-blue-600" />
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="pt-20 pb-6 px-6">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-1">
          {employee.first_name} {employee.last_name}
        </h2>
        <p className="text-center text-sm text-gray-500 mb-6">
          الكود: {employee.employee_code}
        </p>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 text-gray-700">
            <Briefcase className="w-5 h-5 text-blue-600" />
            <span className="font-medium">{employee.position}</span>
          </div>

          <div className="flex items-center gap-3 text-gray-700">
            <Calendar className="w-5 h-5 text-blue-600" />
            <span>{new Date(employee.birth_date).toLocaleDateString('ar-EG')}</span>
          </div>

          <div className="flex items-center gap-3 text-gray-700">
            <Phone className="w-5 h-5 text-blue-600" />
            <span dir="ltr">{employee.phone}</span>
          </div>

          <div className="flex items-center gap-3 text-gray-700">
            <Clock className="w-5 h-5 text-blue-600" />
            <span>
              {employee.work_start_time.substring(0, 5)} - {employee.work_end_time.substring(0, 5)}
            </span>
          </div>
        </div>

        <div className="flex justify-center mb-4">
          <div className="bg-white p-3 rounded-xl shadow-md border-2 border-gray-100">
            <canvas ref={qrCanvasRef} />
          </div>
        </div>

        <p className="text-center text-xs text-gray-500">
          امسح الكود للحضور والانصراف
        </p>
      </div>
    </div>
  );
}
