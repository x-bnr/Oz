import { useEffect, useState } from 'react';
import { Calendar, Filter, Users, CheckCircle, XCircle, Clock } from 'lucide-react';
import { supabase, type AttendanceRecord, type Employee } from '../lib/supabase';

export function AttendanceDashboard() {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedEmployee, setSelectedEmployee] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  useEffect(() => {
    fetchEmployees();
    fetchAttendance();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [records, selectedDate, selectedEmployee, selectedStatus]);

  const fetchEmployees = async () => {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('is_active', true)
      .order('first_name');

    if (!error && data) {
      setEmployees(data);
    }
  };

  const fetchAttendance = async () => {
    const { data, error } = await supabase
      .from('attendance_records')
      .select(`
        *,
        employees (*)
      `)
      .order('check_in', { ascending: false });

    if (!error && data) {
      setRecords(data as AttendanceRecord[]);
    }
  };

  const applyFilters = () => {
    let filtered = [...records];

    if (selectedDate) {
      filtered = filtered.filter((record) => record.date === selectedDate);
    }

    if (selectedEmployee !== 'all') {
      filtered = filtered.filter((record) => record.employee_id === selectedEmployee);
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter((record) => record.status === selectedStatus);
    }

    setFilteredRecords(filtered);
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      present: { color: 'bg-green-100 text-green-800 border-green-200', label: 'حاضر' },
      late: { color: 'bg-yellow-100 text-yellow-800 border-yellow-200', label: 'متأخر' },
      absent: { color: 'bg-red-100 text-red-800 border-red-200', label: 'غائب' },
    };
    const badge = badges[status as keyof typeof badges] || badges.present;
    return (
      <span className={`px-3 py-1 rounded-full text-sm font-semibold border-2 ${badge.color}`}>
        {badge.label}
      </span>
    );
  };

  const formatTime = (datetime: string) => {
    return new Date(datetime).toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const todayStats = records.filter((r) => r.date === selectedDate);
  const presentCount = todayStats.filter((r) => r.status === 'present').length;
  const lateCount = todayStats.filter((r) => r.status === 'late').length;
  const absentCount = employees.length - todayStats.length;

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
        <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
          <Users className="w-8 h-8 text-blue-600" />
          <span>لوحة الحضور والانصراف</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-xl border-2 border-green-200">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <p className="text-sm text-green-700 font-medium">حاضر</p>
                <p className="text-2xl font-bold text-green-800">{presentCount}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-4 rounded-xl border-2 border-yellow-200">
            <div className="flex items-center gap-3">
              <Clock className="w-8 h-8 text-yellow-600" />
              <div>
                <p className="text-sm text-yellow-700 font-medium">متأخر</p>
                <p className="text-2xl font-bold text-yellow-800">{lateCount}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-red-50 to-red-100 p-4 rounded-xl border-2 border-red-200">
            <div className="flex items-center gap-3">
              <XCircle className="w-8 h-8 text-red-600" />
              <div>
                <p className="text-sm text-red-700 font-medium">غائب</p>
                <p className="text-2xl font-bold text-red-800">{absentCount}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-xl mb-6 border-2 border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <Filter className="w-5 h-5 text-gray-700" />
            <h3 className="text-lg font-semibold text-gray-800">الفلاتر</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline ml-1" />
                التاريخ
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Users className="w-4 h-4 inline ml-1" />
                الموظف
              </label>
              <select
                value={selectedEmployee}
                onChange={(e) => setSelectedEmployee(e.target.value)}
                className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">الكل</option>
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.first_name} {emp.last_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Filter className="w-4 h-4 inline ml-1" />
                الحالة
              </label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">الكل</option>
                <option value="present">حاضر</option>
                <option value="late">متأخر</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
              <tr>
                <th className="px-6 py-4 text-right font-semibold">الموظف</th>
                <th className="px-6 py-4 text-right font-semibold">التاريخ</th>
                <th className="px-6 py-4 text-right font-semibold">الحضور</th>
                <th className="px-6 py-4 text-right font-semibold">الانصراف</th>
                <th className="px-6 py-4 text-right font-semibold">الحالة</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    لا توجد سجلات
                  </td>
                </tr>
              ) : (
                filteredRecords.map((record) => (
                  <tr key={record.id} className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-gray-800">
                        {record.employees?.first_name} {record.employees?.last_name}
                      </div>
                      <div className="text-sm text-gray-500">{record.employees?.position}</div>
                    </td>
                    <td className="px-6 py-4 text-gray-700">
                      {new Date(record.date).toLocaleDateString('ar-EG')}
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-800 font-medium">{formatTime(record.check_in)}</span>
                    </td>
                    <td className="px-6 py-4">
                      {record.check_out ? (
                        <span className="text-gray-800 font-medium">{formatTime(record.check_out)}</span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4">{getStatusBadge(record.status)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
