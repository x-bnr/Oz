import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { ScanLine, X, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface QRScannerProps {
  onScanSuccess?: (result: string) => void;
}

export function QRScanner({ onScanSuccess }: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isProcessingRef = useRef(false);

  const startScanning = async () => {
    try {
      setIsScanning(true);
      setMessage(null);

      const scanner = new Html5Qrcode('qr-reader');
      scannerRef.current = scanner;

      await scanner.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        async (decodedText) => {
          if (isProcessingRef.current) return;
          isProcessingRef.current = true;

          await handleScan(decodedText);

          setTimeout(() => {
            isProcessingRef.current = false;
          }, 2000);
        },
        () => {}
      );
    } catch (err) {
      console.error('خطأ في بدء المسح:', err);
      setMessage({ type: 'error', text: 'فشل في بدء الكاميرا' });
      setIsScanning(false);
    }
  };

  const stopScanning = async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
        scannerRef.current = null;
      } catch (err) {
        console.error('خطأ في إيقاف المسح:', err);
      }
    }
    setIsScanning(false);
  };

  const handleScan = async (employeeCode: string) => {
    try {
      const { data: employee, error: employeeError } = await supabase
        .from('employees')
        .select('*')
        .eq('employee_code', employeeCode)
        .eq('is_active', true)
        .maybeSingle();

      if (employeeError || !employee) {
        setMessage({ type: 'error', text: 'موظف غير موجود أو غير نشط' });
        return;
      }

      const today = new Date().toISOString().split('T')[0];
      const now = new Date().toISOString();
      const currentTime = new Date().toTimeString().split(' ')[0];

      const { data: existingRecord, error: recordError } = await supabase
        .from('attendance_records')
        .select('*')
        .eq('employee_id', employee.id)
        .eq('date', today)
        .maybeSingle();

      if (recordError && recordError.code !== 'PGRST116') {
        throw recordError;
      }

      if (!existingRecord) {
        const isLate = currentTime > employee.work_start_time;
        const status = isLate ? 'late' : 'present';

        const { error: insertError } = await supabase
          .from('attendance_records')
          .insert({
            employee_id: employee.id,
            check_in: now,
            date: today,
            status,
          });

        if (insertError) throw insertError;

        setMessage({
          type: 'success',
          text: `تم تسجيل الحضور ${employee.first_name} ${employee.last_name}${isLate ? ' (متأخر)' : ''}`,
        });
      } else if (!existingRecord.check_out) {
        const { error: updateError } = await supabase
          .from('attendance_records')
          .update({ check_out: now })
          .eq('id', existingRecord.id);

        if (updateError) throw updateError;

        setMessage({
          type: 'success',
          text: `تم تسجيل الانصراف ${employee.first_name} ${employee.last_name}`,
        });
      } else {
        setMessage({
          type: 'error',
          text: 'تم تسجيل الحضور والانصراف مسبقاً اليوم',
        });
      }

      if (onScanSuccess) {
        onScanSuccess(employeeCode);
      }
    } catch (err) {
      console.error('خطأ في معالجة المسح:', err);
      setMessage({ type: 'error', text: 'حدث خطأ في تسجيل الحضور' });
    }
  };

  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, []);

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-white rounded-2xl shadow-xl p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          مسح رمز QR
        </h2>

        {!isScanning ? (
          <button
            onClick={startScanning}
            className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-4 rounded-xl font-semibold hover:from-blue-700 hover:to-cyan-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
          >
            <ScanLine className="w-6 h-6" />
            <span>بدء المسح</span>
          </button>
        ) : (
          <>
            <div className="relative mb-4">
              <div id="qr-reader" className="rounded-xl overflow-hidden border-4 border-blue-500"></div>
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-cyan-400"></div>
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-cyan-400"></div>
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-cyan-400"></div>
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-cyan-400"></div>
              </div>
            </div>

            <button
              onClick={stopScanning}
              className="w-full bg-red-500 text-white py-3 rounded-xl font-semibold hover:bg-red-600 transition-colors duration-200 flex items-center justify-center gap-2"
            >
              <X className="w-5 h-5" />
              <span>إيقاف المسح</span>
            </button>
          </>
        )}

        {message && (
          <div
            className={`mt-4 p-4 rounded-xl flex items-center gap-3 ${
              message.type === 'success'
                ? 'bg-green-50 text-green-800 border-2 border-green-200'
                : 'bg-red-50 text-red-800 border-2 border-red-200'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle className="w-6 h-6 flex-shrink-0" />
            ) : (
              <XCircle className="w-6 h-6 flex-shrink-0" />
            )}
            <p className="font-medium">{message.text}</p>
          </div>
        )}
      </div>
    </div>
  );
}
