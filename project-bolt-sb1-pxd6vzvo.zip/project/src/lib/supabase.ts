import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Employee {
  id: string;
  employee_code: string;
  first_name: string;
  last_name: string;
  birth_date: string;
  phone: string;
  position: string;
  photo_url: string;
  work_start_time: string;
  work_end_time: string;
  is_active: boolean;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  employee_id: string;
  check_in: string;
  check_out: string | null;
  date: string;
  status: 'present' | 'absent' | 'late';
  notes: string;
  created_at: string;
  employees?: Employee;
}
