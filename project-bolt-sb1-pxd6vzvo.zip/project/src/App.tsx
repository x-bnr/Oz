import { useState } from 'react';
import { QrCode, Users, BarChart3 } from 'lucide-react';
import { QRScanner } from './components/QRScanner';
import { EmployeeManagement } from './components/EmployeeManagement';
import { AttendanceDashboard } from './components/AttendanceDashboard';

function App() {
  const [activeTab, setActiveTab] = useState<'scanner' | 'employees' | 'dashboard'>('scanner');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-cyan-50">
      <div className="container mx-auto px-4 py-8">
        <header className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-center mb-2 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            نظام الحضور والانصراف
          </h1>
          <p className="text-center text-gray-600 text-lg">
            نظام متكامل لإدارة حضور الموظفين باستخدام QR Code
          </p>
        </header>

        <nav className="mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-2 max-w-2xl mx-auto">
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setActiveTab('scanner')}
                className={`py-4 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 ${
                  activeTab === 'scanner'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <QrCode className="w-5 h-5" />
                <span className="hidden md:inline">مسح QR</span>
              </button>

              <button
                onClick={() => setActiveTab('employees')}
                className={`py-4 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 ${
                  activeTab === 'employees'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Users className="w-5 h-5" />
                <span className="hidden md:inline">الموظفين</span>
              </button>

              <button
                onClick={() => setActiveTab('dashboard')}
                className={`py-4 px-6 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 ${
                  activeTab === 'dashboard'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <BarChart3 className="w-5 h-5" />
                <span className="hidden md:inline">التقارير</span>
              </button>
            </div>
          </div>
        </nav>

        <main>
          {activeTab === 'scanner' && (
            <div className="animate-fadeIn">
              <QRScanner />
            </div>
          )}

          {activeTab === 'employees' && (
            <div className="animate-fadeIn">
              <EmployeeManagement />
            </div>
          )}

          {activeTab === 'dashboard' && (
            <div className="animate-fadeIn">
              <AttendanceDashboard />
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
