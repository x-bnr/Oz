/*
  # نظام تسجيل الحضور والانصراف - Attendance System

  ## 1. الجداول الجديدة (New Tables)
  
  ### `employees` - جدول الموظفين
    - `id` (uuid, primary key) - المعرف الفريد
    - `employee_code` (text, unique) - كود الموظف الفريد للـ QR
    - `first_name` (text) - الاسم الأول
    - `last_name` (text) - اللقب
    - `birth_date` (date) - تاريخ الميلاد
    - `phone` (text) - رقم الهاتف
    - `position` (text) - المهنة/الوظيفة
    - `photo_url` (text) - رابط صورة الموظف
    - `work_start_time` (time) - وقت بداية العمل (7 صباحاً)
    - `work_end_time` (time) - وقت نهاية العمل (3 مساءً)
    - `is_active` (boolean) - حالة الموظف نشط/غير نشط
    - `created_at` (timestamptz) - تاريخ الإنشاء

  ### `attendance_records` - جدول سجلات الحضور
    - `id` (uuid, primary key) - المعرف الفريد
    - `employee_id` (uuid, foreign key) - معرف الموظف
    - `check_in` (timestamptz) - وقت الحضور
    - `check_out` (timestamptz, nullable) - وقت الانصراف
    - `date` (date) - تاريخ اليوم
    - `status` (text) - حالة الحضور (present/absent/late)
    - `notes` (text, nullable) - ملاحظات
    - `created_at` (timestamptz) - تاريخ الإنشاء

  ## 2. الأمان (Security)
    - تفعيل RLS على جميع الجداول
    - سياسات القراءة والكتابة للمستخدمين المصادق عليهم
    
  ## 3. الفهارس (Indexes)
    - فهرس على employee_code للبحث السريع
    - فهرس على date و employee_id لتسريع الاستعلامات
*/

-- Create employees table
CREATE TABLE IF NOT EXISTS employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_code text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  birth_date date NOT NULL,
  phone text NOT NULL,
  position text NOT NULL,
  photo_url text DEFAULT '',
  work_start_time time DEFAULT '07:00:00',
  work_end_time time DEFAULT '15:00:00',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create attendance records table
CREATE TABLE IF NOT EXISTS attendance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  check_in timestamptz NOT NULL,
  check_out timestamptz,
  date date NOT NULL,
  status text NOT NULL DEFAULT 'present',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_employees_code ON employees(employee_code);
CREATE INDEX IF NOT EXISTS idx_employees_active ON employees(is_active);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance_records(date);
CREATE INDEX IF NOT EXISTS idx_attendance_employee ON attendance_records(employee_id);
CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON attendance_records(employee_id, date);

-- Enable Row Level Security
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records ENABLE ROW LEVEL SECURITY;

-- Policies for employees table
CREATE POLICY "Allow authenticated users to read employees"
  ON employees FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert employees"
  ON employees FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update employees"
  ON employees FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete employees"
  ON employees FOR DELETE
  TO authenticated
  USING (true);

-- Policies for attendance_records table
CREATE POLICY "Allow authenticated users to read attendance"
  ON attendance_records FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert attendance"
  ON attendance_records FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update attendance"
  ON attendance_records FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete attendance"
  ON attendance_records FOR DELETE
  TO authenticated
  USING (true);